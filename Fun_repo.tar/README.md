# Quantum Entanglement Window (QEW) Experiment

This repository contains a standalone Python program that simulates a toy model of
a **Quantum Entanglement Window** (QEW) between two black‑hole analogues.  The
goal of the simulation is to reproduce some of the qualitative behaviour
discussed in recent literature on entanglement wedge connectivity and Hayden–
Preskill recovery.  Specifically, it demonstrates how swapping a fraction of
Hawking radiation between two subsystems can open a geometric `window' through
which quantum information may be recovered.

## Overview

The experiment models two registers, `A` and `B`, each consisting of `n` qubits.
An additional reference qubit `R` is maximally entangled with the first qubit
of `A`—this qubit represents a ``diary'' that will be scrambled and partially
evaporated.  The simulation proceeds in four stages:

1. **Scrambling:**  Each register is scrambled independently with a random
   Haar–distributed unitary of dimension `2**n`.  Scrambling mimics the
   chaotic dynamics of a black hole.
2. **Exchange:**  A fraction `p = k/n` of qubits is swapped between `A` and
   `B`.  Swapping corresponds to exchanging Hawking radiation between the two
   horizons.  When `p` exceeds a critical value `p*`, a connected
   entanglement wedge is expected to emerge.
3. **Measurements:**  After scrambling and exchange, several information
   theoretic quantities are computed:
   * **Mutual information** `I(R_A:R_B)` between the sets of exchanged qubits.
   * **Negativity** (an entanglement monotone) between the exchanged qubits.
   * **Out‑of‑time‑order correlator (OTOC)** for a pair of local Pauli
     operators.  The OTOC quantifies operator growth and scrambling.
4. **Repetition:**  The procedure is repeated for different values of `k` and
   averaged over multiple Haar random realisations to smooth statistical
   fluctuations.

The code produces a table of the computed metrics and optionally plots them
against the exchange fraction `p`.  Although simplified, this simulation
captures the essential ingredients needed to explore entanglement wedge
connectivity in a controlled setting.

## Requirements

The program depends only on standard scientific Python libraries.  To run
the experiment you should install the following packages:

```bash
pip install numpy scipy matplotlib
```

No quantum‑specific framework (such as Qiskit or QuTiP) is required.  All
linear algebra is performed with NumPy and SciPy.

## Running the Simulation

Execute the script with Python 3.11 or later:

```bash
python qew_experiment.py
```

By default, the script runs the simulation for two systems of four qubits
(`n=4`) and swaps `k=1,2` qubits.  You can modify `n`, `k_values`,
`scramble_steps`, and `samples` in the `simulate()` function call at the
bottom of the file to explore different regimes.  When run, the program
prints a summary table and creates a PNG plot in the current directory.

## File Structure

* `qew_experiment.py` – main Python program implementing the simulation and
  plotting routines.
* `README.md` – this overview and usage guide.
* `requirements.txt` – minimal set of required Python packages.

## Limitations and Future Work

This code is a proof‑of‑concept and leaves room for many refinements.  In
particular:

* The **reflected entropy** `S_R` is not implemented.  It is replaced here
  by the negativity, which still serves as an entanglement witness but is
  computationally simpler.  Implementing `S_R` requires a doubled Hilbert
  space and more careful bookkeeping.
* The **Petz or Yoshida–Kitaev recovery map** is not included.  Recovering
  the diary qubit from subsystem `B` would require constructing a quantum
  channel inverse; this is an interesting challenge left for future work.
* The simulation uses small numbers of qubits (typically `n ≤ 4`) to keep
  computations tractable.  Extending to larger systems will increase the
  Hilbert space exponentially and may require optimisation or approximations.

Despite these simplifications, the experiment provides a solid starting point
for exploring entanglement wedge connectivity and testing conjectures about
quantum information recovery.